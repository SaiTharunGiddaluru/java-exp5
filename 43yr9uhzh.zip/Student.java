import java.io.Serializable;

// Student class implementing Serializable
public class Student implements Serializable {
    private static final long serialVersionUID = 1L;  // Recommended for Serializable classes

    private int studentID;
    private String name;
    private double grade;

    // Constructor
    public Student(int studentID, String name, double grade) {
        this.studentID = studentID;
        this.name = name;
        this.grade = grade;
    }

    // Getters
    public int getStudentID() {
        return studentID;
    }

    public String getName() {
        return name;
    }

    public double getGrade() {
        return grade;
    }

    @Override
    public String toString() {
        return "Student [ID=" + studentID + ", Name=" + name + ", Grade=" + grade + "]";
    }
}
