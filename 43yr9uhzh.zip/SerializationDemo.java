import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;

public class SerializationDemo {
    public static void main(String[] args) {
        // Create a Student object
        Student student = new Student(101, "Alice", 92.5);

        // --- Serialization ---
        try (FileOutputStream fileOut = new FileOutputStream("student.ser");
             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {

            out.writeObject(student);  // Save object to file
            System.out.println("Student object has been serialized to student.ser");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // --- Deserialization ---
        try (FileInputStream fileIn = new FileInputStream("student.ser");
             ObjectInputStream in = new ObjectInputStream(fileIn)) {

            Student deserializedStudent = (Student) in.readObject();  // Reconstruct object
            System.out.println("Deserialized Student object:");
            System.out.println(deserializedStudent);

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
