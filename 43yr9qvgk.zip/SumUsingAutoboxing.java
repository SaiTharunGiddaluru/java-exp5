import java.util.ArrayList;
import java.util.Scanner;

public class SumUsingAutoboxing {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> numbers = new ArrayList<>();

        System.out.println("Enter integers one by one (type 'done' to finish):");

        while (true) {
            String input = scanner.nextLine();

            // Stop input when user types "done"
            if (input.equalsIgnoreCase("done")) {
                break;
            }

            try {
                // Parse string to int and autobox to Integer
                Integer num = Integer.parseInt(input);  // String parsing
                numbers.add(num);                       // Autoboxing happens here
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer or 'done'.");
            }
        }

        // Calculate sum using unboxing
        int sum = 0;
        for (Integer number : numbers) {
            sum += number;  // Unboxing from Integer to int happens automatically
        }

        System.out.println("The sum of the entered integers is: " + sum);
        scanner.close();
    }
}
